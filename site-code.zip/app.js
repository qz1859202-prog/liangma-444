import {attachFilmCacheButton} from './mediaCache.js';
import {startMediaWarmup} from './mediaWarmup.js';
import {playbackURL} from './mediaQuality.js';
import {mountWorkflowStage} from './workflow/workflow-stage.js';
import {works} from './collection.js';
import {team} from './team.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const touch=matchMedia('(pointer: coarse)').matches;
const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
let activePreview=null,previewTimer=null,previewSession=null;
function attachVideo(video,work,onError){let hls=null,prepared=false;video.controls=false;video.poster='.'+work.poster;const source=()=>'.'+playbackURL(work);const url=source();video.preload='metadata';const prepare=()=>{if(prepared)return;prepared=true;video.controls=false;if(!url.endsWith('.m3u8')||video.canPlayType('application/vnd.apple.mpegurl')){video.src=source();video.load();}else if(window.Hls?.isSupported()){hls=new Hls({maxBufferLength:12,maxMaxBufferLength:20,backBufferLength:0,startLevel:0});hls.loadSource(url);hls.attachMedia(video);hls.on(Hls.Events.ERROR,(_,data)=>{if(data.fatal)onError?.();});}else onError?.();};return{prepare,destroy(){hls?.destroy();video.pause();video.removeAttribute('src');video.load();}};}
function stopPreview(reset=false){clearTimeout(previewTimer);previewSession?.destroy();previewSession=null;if(activePreview){activePreview.classList.remove('is-playing');if(reset){const w=works[Number(activePreview.dataset.index)];activePreview.classList.remove('is-flipped');activePreview.setAttribute('aria-expanded','false');activePreview.setAttribute('aria-label',`翻转并预览作品：${w.zh}`);activePreview=null;}}if(reset)$('#grid-hint').textContent='点击翻面预览，再次点击打开作品 ↗';}
const groups={brand:'BRAND FILM',product:'PRODUCT VISUAL',art:'ART & EXPERIMENT'};
function tileMarkup(work,index){return `<button type="button" class="film-tile" data-index="${index}" aria-label="翻转并预览作品：${work.zh}" aria-expanded="false" aria-haspopup="dialog" aria-describedby="grid-hint"><span class="tile-inner"><span class="tile-front"><span class="tile-meta"><span>QT / ${work.number}</span><i aria-hidden="true">＋</i></span><strong>${work.title}</strong><span class="tile-caption">${work.zh}</span><span class="tile-footer"><small>${groups[work.group]}</small><span>${work.durationLabel} <i>▷ 点击翻面</i></span></span></span><span class="tile-back" style="background-image:url(${work.thumbnail});background-size:cover"><img src=".${work.poster}" alt="" draggable="false" loading="eager" decoding="async"><video class="tile-video" muted playsinline loop preload="none" aria-hidden="true" tabindex="-1"></video><span class="tile-back-meta"><span>${work.number} / MUTED PREVIEW</span><i>↗</i></span><span class="tile-back-caption"><span>${work.zh}</span><small>再次点击 · 打开作品</small></span></span></span></button>`;}
$('#work-grid').insertAdjacentHTML('beforeend',works.slice(0,8).map(tileMarkup).join(''));
$('#taper-grid').innerHTML=works.slice(8).map((w,i)=>tileMarkup(w,i+8)).join('');
$$('.film-tile').forEach(el=>el.addEventListener('click',()=>{const work=works[Number(el.dataset.index)];if(el.classList.contains('is-flipped')){openFilm(work.id);return;}stopPreview(true);activePreview=el;el.classList.add('is-flipped');el.setAttribute('aria-expanded','true');el.setAttribute('aria-label',`打开作品小窗：${work.zh}`);$('#grid-hint').textContent=`正在预览：${work.zh} · 再点一次打开作品 · Esc 收起`;const v=el.querySelector('video');v.muted=true;previewSession=attachVideo(v,{...work,video:work.video.replace('playback.mp4','preview-hd.mp4')});v.addEventListener('playing',()=>{if(activePreview===el)el.classList.add('is-playing');},{once:true});previewSession.prepare();prepareMainFilm(work,'metadata');v.play().catch(()=>{$('#grid-hint').textContent='点击预览画面，打开完整作品 ↗';});}));
const previewObserver=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.target===activePreview&&!entry.isIntersecting)stopPreview();},{threshold:0});
$$('.film-tile').forEach(el=>previewObserver.observe(el));
const motifs=[`<circle cx="100" cy="100" r="68"/><ellipse cx="100" cy="100" rx="25" ry="68"/><ellipse cx="100" cy="100" rx="50" ry="68"/><path d="M34 75H166M34 125H166M32 100H168"/>`,`<path d="M30 55 75 30 125 55 170 30V145L125 170 75 145 30 170ZM75 30V145M125 55V170M30 95 75 70 125 95 170 70"/>`,`<circle cx="100" cy="100" r="58"/><circle cx="80" cy="88" r="45"/><circle cx="120" cy="88" r="45"/><circle cx="100" cy="122" r="45"/>`,`<path d="M100 28 162 64 162 136 100 172 38 136 38 64Z M38 64 100 100 162 64M100 100V172M100 28V100M38 136 100 100 162 136"/>`,`<circle cx="100" cy="100" r="62"/><ellipse cx="100" cy="100" rx="80" ry="23" transform="rotate(-35 100 100)"/><ellipse cx="100" cy="100" rx="80" ry="23" transform="rotate(35 100 100)"/><circle cx="100" cy="100" r="8"/>`,`<path d="M40 135Q40 35 100 35T160 135Q100 195 40 135ZM50 132Q100 50 150 132M65 142Q100 80 135 142M82 150Q100 110 118 150"/>`,`<path d="M100 25V175M25 100H175M47 47 153 153M47 153 153 47M73 30 127 170M30 73 170 127M30 127 170 73M73 170 127 30"/><circle cx="100" cy="100" r="42"/>`];
const viewer=$('#viewer'),video=$('#main-video');let current=-1,mainSession=null,mainPreparedId=null,lastFocus=null,closeTimer,mainCacheCleanup;
function prepareMainFilm(work,preload='auto'){if(mainPreparedId!==work.id){mainSession?.destroy();mainSession=attachVideo(video,work,()=>{$('#video-status').textContent='加载未完成，请点击重试。';$('#play-main').hidden=false;});mainPreparedId=work.id;}video.preload=preload;mainSession.prepare();}

function lock(){document.body.classList.add('locked');}function unlock(){if(!$$('dialog[open]').length)document.body.classList.remove('locked');}
function openFilm(id,updateUrl=true){mainPlayPending=false;clearTimeout(mainPlayTimer);const i=works.findIndex(w=>w.id===id);if(i<0)return;stopPreview();if($('#index-dialog').open)$('#index-dialog').close();const wasOpen=viewer.open;if(!wasOpen)lastFocus=document.activeElement;video.pause();current=i;const w=works[i];$('#viewer-title').textContent=w.zh;$('#viewer-en').textContent=w.title;$('#viewer-duration').textContent=w.durationLabel;$('#viewer-desc').textContent=w.description;$('#work-count').textContent=`${w.number} / 10`;$('#project-notes').hidden=true;$('#show-notes').setAttribute('aria-expanded','false');$('#project-notes').innerHTML=`<p>${w.note}</p><p>${w.process}</p><p>类型 / ${({brand:'品牌影像',product:'产品视觉',art:'艺术短片'})[w.group]} · 影片时长 / ${w.durationLabel}</p>`;$('#play-main').hidden=false;$('#video-status').textContent='';$('#previous-work').disabled=i===0;$('#next-work').disabled=i===works.length-1;video.muted=false;video.loop=false;prepareMainFilm(w);mainCacheCleanup?.();mainCacheCleanup=attachFilmCacheButton($('#save-main-film'),video,'.'+w.video);if(!viewer.open){viewer.showModal();lock();}if(updateUrl&&!/MicroMessenger/i.test(navigator.userAgent))history.pushState({film:id},'',`#film/${id}`);}
function closeFilm(restoreHash=true){if(!viewer.open)return;mainPlayPending=false;clearTimeout(mainPlayTimer);mainSession?.destroy();mainSession=null;mainPreparedId=null;mainCacheCleanup?.();viewer.close();viewer.classList.remove('expanded');$('#expand-window').setAttribute('aria-pressed','false');$('#expand-window').setAttribute('aria-label','放大作品小窗');unlock();if(restoreHash&&!/MicroMessenger/i.test(navigator.userAgent)&&location.hash.startsWith('#film/'))history.replaceState(null,'','#top');lastFocus?.focus({preventScroll:true});}
$('#close-viewer').addEventListener('click',()=>closeFilm());viewer.addEventListener('cancel',e=>{e.preventDefault();closeFilm();});let mainPlayPending=false,mainPlayTimer;function startMainPlayback(){if(mainPlayPending)return;mainPlayPending=true;clearTimeout(mainPlayTimer);mainPlayTimer=setTimeout(()=>{mainPlayPending=false;$('#video-status').textContent='网络响应较慢，仍在缓冲，可关闭后重试。';},12000);if(video.error){mainSession?.destroy();mainSession=null;mainPreparedId=null;prepareMainFilm(works[current]);}$('#video-status').textContent='正在加载影片…';video.preload='auto';mainSession?.prepare();video.play().then(()=>{mainPlayPending=false;clearTimeout(mainPlayTimer);$('#play-main').hidden=true;$('#video-status').textContent='';}).catch(()=>{mainPlayPending=false;clearTimeout(mainPlayTimer);$('#video-status').textContent='暂未能播放，请再试一次。';});}$('#play-main').addEventListener('click',startMainPlayback);video.addEventListener('playing',()=>{video.controls=true;$('#play-main').hidden=true;$('#video-status').textContent='';});$('#expand-window').addEventListener('click',()=>{const expanded=viewer.classList.toggle('expanded');$('#expand-window').setAttribute('aria-pressed',expanded);$('#expand-window').setAttribute('aria-label',expanded?'还原作品小窗':'放大作品小窗');});$('#previous-work').addEventListener('click',()=>{if(current>0)openFilm(works[current-1].id);});$('#next-work').addEventListener('click',()=>{if(current<works.length-1)openFilm(works[current+1].id);});$('#show-notes').addEventListener('click',()=>{const p=$('#project-notes');p.hidden=!p.hidden;$('#show-notes').setAttribute('aria-expanded',!p.hidden);if(!p.hidden)p.scrollIntoView({block:'nearest',behavior:reduce?'instant':'smooth'});});$('#open-company').addEventListener('click',()=>{closeFilm(false);history.pushState(null,'','#studio');$('#studio').scrollIntoView({behavior:reduce?'instant':'smooth'});});function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(closeTimer);closeTimer=setTimeout(()=>$('#toast').classList.remove('visible'),3500);}$('#share-work').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(location.href);toast('作品链接已复制，可以分享给朋友。');}catch{toast('请复制浏览器地址栏中的作品链接。');}});
function renderIndex(filter='all'){$('#index-list').innerHTML=works.filter(w=>filter==='all'||w.group===filter).map(w=>`<button class="index-row" data-work="${w.id}" aria-label="在小窗打开${w.zh}"><span>${w.number}</span><img src=".${w.poster}" alt=""><div><b>${w.zh}</b><small>${w.title}</small></div><span>${w.durationLabel}</span><span>↗</span></button>`).join('');$$('.index-row').forEach(el=>el.addEventListener('click',()=>openFilm(el.dataset.work)));}
renderIndex();$('#open-index').addEventListener('click',()=>{$('#index-dialog').showModal();lock();});$('#close-index').addEventListener('click',()=>{$('#index-dialog').close();unlock();});$$('[data-filter]').forEach(b=>b.addEventListener('click',()=>{$$('[data-filter]').forEach(x=>x.setAttribute('aria-pressed',x===b));renderIndex(b.dataset.filter);}));$('#index-dialog').addEventListener('close',unlock);
const contactDialog=$('#contact-dialog');function contact(kind){const wechat=kind==='wechat';$('#contact-dialog-title').textContent=wechat?'先打个招呼。':'你的想法，从这里开始。';$('#contact-dialog-copy').innerHTML=wechat?`<p>欢迎与量孖聊聊新的创作与合作。</p><div class="placeholder-box">微信二维码 / 微信号<br><small>正式联系方式待补充</small></div><small>微信、邮箱与正式合作信息待补充。</small>`:`<p>一个项目、一段影像，或一个还未成形的念头。</p><div class="brief-directions"><span>品牌宣传</span><span>产品视觉</span><span>艺术短片</span><span>其他想法</span></div><p>合作时可以准备：项目方向、观看场景、时间计划、预算范围、已有素材与期待的表达。</p><div class="placeholder-box">项目联系邮箱 / 微信<br><small>正式联系方式待补充</small></div><small>本预览尚未接入提交或发送服务。</small>`;contactDialog.showModal();lock();}$('#contact-wechat').addEventListener('click',()=>contact('wechat'));$('#contact-brief').addEventListener('click',()=>contact('brief'));$('#close-contact').addEventListener('click',()=>{contactDialog.close();unlock();});contactDialog.addEventListener('close',unlock);
// An uninterrupted line connects the people, surrounds the studio, then becomes roots.
const rowOffsets=[7,12,18,5,10,17,9],rowTurns=[-3,2,-2,4,-4,3,-2];
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
$('#team-timeline').innerHTML=team.map((member,i)=>{
 const pending=!!member.pending||!member.name;
 const label=pending?'More perspectives.':escapeHtml(member.name);
 const name=`<span class="frame-name"><span class="frame-en">${pending?'TO BE CONTINUED':escapeHtml(member.en)}</span><strong>${label}</strong><small>${pending?'新的视角，即将相遇':escapeHtml(member.role||'关于创作者的故事，即将呈现')}</small></span>`;
 const portrait=member.photo?`<img class="frame-portrait" src="${escapeHtml(member.photo)}" alt="${escapeHtml(member.name)}的形象照片" loading="lazy" draggable="false">`:`<svg viewBox="0 0 200 200" fill="none" stroke="currentColor" stroke-width=".8" aria-hidden="true">${motifs[i]}</svg>`;
 const inside=`${portrait}<span class="frame-code">${pending?'AN OPEN PERSPECTIVE':`PERSON / 0${i+1}`}<i aria-hidden="true">${pending?'+':'↗'}</i></span>${name}`;
 const frame=pending?`<div class="member-frame is-pending" aria-label="新的视角，即将相遇">${inside}</div>`:`<button type="button" class="member-frame has-portrait" data-person="${i}" aria-label="展开${escapeHtml(member.name)}的资料" aria-expanded="false">${inside}</button>`;
 const summary=member.bio?member.bio.split('\n')[0]:'关于这位创作者的故事，即将呈现。';
 const peek=pending?'':`<div class="member-peek"><span class="eyebrow">0${i+1} / ${escapeHtml(member.en)}</span><h3>${escapeHtml(member.name)}</h3>${member.role?`<p>${escapeHtml(member.role)}</p>`:''}<small>${escapeHtml(summary)}</small><button type="button" data-member="${i}" aria-haspopup="dialog">个人介绍与作品 <span>↗</span></button></div>`;
 return `<li class="member-row ${i%2?'right':'left'} ${pending?'is-pending':''}" style="--offset:${rowOffsets[i]}%;--tilt:${rowTurns[i]}deg"><div class="member-anchor">${frame}</div>${peek}</li>`;
}).join('');
$$('[data-person]').forEach(button=>{
 const row=button.closest('.member-row');
 const sync=()=>button.setAttribute('aria-expanded',row.matches(':focus-within')||row.classList.contains('is-hovered')||row.classList.contains('is-peeking'));
 button.addEventListener('pointerenter',()=>{row.classList.add('is-hovered');sync();});
 row.addEventListener('pointerleave',()=>{row.classList.remove('is-hovered');sync();});
 button.addEventListener('focus',sync);row.addEventListener('focusout',()=>requestAnimationFrame(sync));
 button.addEventListener('click',()=>{
  if(matchMedia('(hover:none)').matches){
   const active=!row.classList.contains('is-peeking');
   $$('.member-row').forEach(r=>{r.classList.remove('is-peeking');r.querySelector('[data-person]')?.setAttribute('aria-expanded','false');});
   row.classList.toggle('is-peeking',active);if(!active){row.classList.remove('is-hovered');button.blur();}sync();scheduleMeasure();
  }else openMember(Number(button.dataset.person),button);
 });
});
let measurePending=false,scrollPending=false;
function measureThread(){measurePending=false;const journey=$('#journey'),rect=journey.getBoundingClientRect(),frame=$('#company-frame').getBoundingClientRect(),w=journey.clientWidth,h=journey.offsetHeight,x=w/2,l=frame.left-rect.left,r=frame.right-rect.left,t=frame.top-rect.top,b=frame.bottom-rect.top;$('#journey-line').setAttribute('viewBox',`0 0 ${w} ${h}`);$('#thread-trunk').setAttribute('d',`M${x} 0V${Math.max(0,t-50)}`);$('#thread-frame-left').setAttribute('d',`M${x} ${t-50}Q${x} ${t} ${x-42} ${t}H${l}V${b}H${x}`);$('#thread-frame-right').setAttribute('d',`M${x} ${t-50}Q${x} ${t} ${x+42} ${t}H${r}V${b}H${x}`);const root=$('#root-garden').getBoundingClientRect();$('#thread-exit').setAttribute('d',`M${x} ${b}V${root.top-rect.top+1}`);$('#member-connectors').innerHTML=$$('.member-frame').map(button=>{const q=button.getBoundingClientRect(),y=q.top-rect.top+q.height/2,end=button.closest('.member-row').classList.contains('left')?q.right-rect.left:q.left-rect.left;return `<path d="M${x} ${y}H${end}"/><circle cx="${x}" cy="${y}" r="3"/>`;}).join('');drawRoots();updateThreadScroll();}
function scheduleMeasure(){if(measurePending)return;measurePending=true;requestAnimationFrame(measureThread);}
function drawRoots(){const box=$('#root-garden'),w=box.clientWidth,h=box.clientHeight,x=w/2;$('#root-lines').setAttribute('viewBox',`0 0 ${w} ${h}`);const rand=n=>{const a=Math.sin(n*18.127)*46391.52;return a-Math.floor(a);};$('#root-paths').innerHTML=Array.from({length:64},(_,i)=>{const side=i%2?-1:1,spread=.08+rand(i+7)*.86,end=x+side*w*.48*spread,split=22+rand(i+4)*h*.42,endY=h*(.62+rand(i+31)*.36),bend=x+side*(15+rand(i+11)*w*.08);return `<path d="M${x} 0C${x} ${split*.5} ${x} ${split} ${bend} ${split+35}S${end} ${endY-90} ${end} ${endY}" opacity="${.16+rand(i+17)*.4}"/>`;}).join('');}
function updateThreadScroll(){scrollPending=false;if(reduce||touch)return;const j=$('#journey'),rect=j.getBoundingClientRect(),visible=Math.max(0,Math.min(rect.height,innerHeight-rect.top));j.style.setProperty('--thread-visible',`${visible/Math.max(1,rect.height)*100}%`);}
window.addEventListener('scroll',()=>{if(!scrollPending){scrollPending=true;requestAnimationFrame(updateThreadScroll);}},{passive:true});
window.addEventListener('resize',scheduleMeasure,{passive:true});new ResizeObserver(scheduleMeasure).observe($('#journey'));new ResizeObserver(scheduleMeasure).observe($('#company-frame'));document.fonts.ready.then(scheduleMeasure);scheduleMeasure();
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$$('dialog[open]').length)stopPreview(true);});
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopPreview();video.pause();memberVideo.pause();}});
window.addEventListener('popstate',()=>{
if(location.hash.startsWith('#film/'))openFilm(location.hash.slice(6),false);else closeFilm(false);});
window.addEventListener('hashchange',()=>{
if(location.hash.startsWith('#film/'))openFilm(location.hash.slice(6),false);});

// Profiles use supplied biographies; the film shelf is explicitly a studio selection.
const memberDialog=$('#member-dialog'),memberVideo=$('#member-video');
let selectedMember=null,memberPortfolio=[],memberWorkIndex=0,memberSession=null,memberOrigin=null,memberCacheCleanup;
function selectMemberWork(index){
 if(index<0||index>=memberPortfolio.length)return;
 memberSession?.destroy();memberSession=null;memberWorkIndex=index;
 const work=memberPortfolio[index];
 $('#member-work-title').textContent=work.zh;$('#member-work-duration').textContent=work.durationLabel;
 $('#member-work-count').textContent=`${String(index+1).padStart(2,'0')} / ${String(memberPortfolio.length).padStart(2,'0')}`;
 $('#play-member').hidden=false;$('#member-video-status').textContent='';
 $$('.member-work').forEach((button,i)=>button.setAttribute('aria-pressed',i===index));
 memberVideo.muted=false;memberVideo.loop=false;
 memberSession=attachVideo(memberVideo,work,()=>{$('#member-video-status').textContent='影片暂不可用，请切换另一部作品。';$('#play-member').hidden=false;});memberVideo.preload='auto';memberSession.prepare();memberCacheCleanup?.();memberCacheCleanup=attachFilmCacheButton($('#save-member-film'),memberVideo,'.'+work.video);
}
function openMember(index,origin){
 const member=team[index];if(!member||member.pending||!member.name)return;
 stopPreview();selectedMember=member;memberOrigin=origin;
 $('#member-number').textContent=`${String(index+1).padStart(2,'0')} / ${member.en||'QUANTUM TWINS'}`;
 $('#member-name').textContent=member.name;
 $('#member-role').textContent=member.role||'';$('#member-role').hidden=!member.role;
 $('#member-bio').textContent=member.bio||'关于这位创作者的故事，即将呈现。';
 $('#member-highlights').replaceChildren(...(member.highlights||[]).map(text=>{const li=document.createElement('li');li.textContent=text;return li;}));
 const portrait=$('#member-photo');portrait.hidden=!member.photo;if(member.photo){portrait.src=member.photo;portrait.alt=`${member.name}的形象照片`;}else portrait.removeAttribute('src');
 $('#member-symbol').hidden=!!member.photo;$('#member-symbol').innerHTML=motifs[index];
 memberPortfolio=member.workIds?.length?member.workIds.map(id=>works.find(w=>w.id===id)).filter(Boolean):works.slice(0,5);
 $('#member-demo-note').hidden=!!member.workIds?.length;
 $('#member-work-list').innerHTML=memberPortfolio.map((work,i)=>`<button class="member-work" type="button" data-member-work="${i}" aria-label="预览工作室作品${work.zh}" aria-pressed="${i===0}"><img src=".${work.poster}" alt="${work.zh}封面" loading="lazy" draggable="false"><small>${work.zh}</small></button>`).join('');
 $$('.member-work').forEach(button=>button.addEventListener('click',()=>selectMemberWork(Number(button.dataset.memberWork))));
 memberDialog.showModal();lock();$('#member-work-list').scrollLeft=0;$('.member-body').scrollTop=0;selectMemberWork(0);
}
function closeMember(){if(!memberDialog.open)return;memberSession?.destroy();memberSession=null;memberCacheCleanup?.();memberDialog.close();unlock();memberOrigin?.focus({preventScroll:true});}
$$('[data-member]').forEach(button=>button.addEventListener('click',()=>openMember(Number(button.dataset.member),button)));
$('#close-member').addEventListener('click',closeMember);
memberDialog.addEventListener('cancel',event=>{event.preventDefault();closeMember();});
$('#play-member').addEventListener('click',()=>{
 if(memberVideo.error)selectMemberWork(memberWorkIndex);
 $('#member-video-status').textContent='正在加载影片…';
 memberSession?.prepare();memberVideo.play().then(()=>{$('#play-member').hidden=true;$('#member-video-status').textContent='';}).catch(()=>{$('#member-video-status').textContent='暂未能播放，请再试一次。';});
});
memberVideo.addEventListener('playing',()=>{memberVideo.controls=true;$('#play-member').hidden=true;$('#member-video-status').textContent='';});
$('#member-previous').addEventListener('click',()=>$('#member-work-list').scrollBy({left:-270,behavior:reduce?'instant':'smooth'}));
$('#member-next').addEventListener('click',()=>$('#member-work-list').scrollBy({left:270,behavior:reduce?'instant':'smooth'}));
document.addEventListener('visibilitychange',()=>{if(document.hidden)memberVideo.pause();});


if(location.hash.startsWith('#film/'))openFilm(decodeURIComponent(location.hash.slice(6)),false);

const workflowStage=mountWorkflowStage(document.querySelector('#workflow-stage'),{theme:'blue',images:['./workflow/scene-01.webp','./workflow/scene-02.webp']});
window.addEventListener('pagehide',event=>{if(!event.persisted)workflowStage.destroy();});


const stopMediaWarmup=startMediaWarmup(works);
window.addEventListener("pagehide",e=>{if(!e.persisted)stopMediaWarmup();});
