import {initialQuality,playbackURL} from './mediaQuality.js';
export function mediaAssetURL(path,base=document.baseURI){const directory=new URL('./',base),url=new URL(path,base);return path.startsWith('/')&&!url.pathname.startsWith(directory.pathname)?new URL('.'+path,directory).href:url.href;}
// One small range request at a time. Never downloads complete films in the background.
export function startMediaWarmup(works){
 let stopped=false,timer=0,controller=null,index=0,attempts=0;
 const urls=[...new Set(works.map(w=>mediaAssetURL(playbackURL(w,initialQuality()))))];
 const bytes=navigator.connection?.saveData?65536:131072;
 const dialogOpen=()=>!!document.querySelector('dialog[open],[role="dialog"][data-state="open"]');
 const activeFilm=()=>[...document.querySelectorAll('.viewer-art video,.profile-film video,#main-video,#member-video')].some(v=>!v.paused&&!v.ended);
 const schedule=(delay=1500)=>{clearTimeout(timer);if(!stopped&&!document.hidden&&index<urls.length&&attempts<20)timer=setTimeout(run,delay);};
 async function run(){
  timer=0;if(stopped||index>=urls.length||attempts>=20)return;
  if(document.hidden||navigator.onLine===false||dialogOpen()||activeFilm()){schedule(2000);return;}
  controller=new AbortController();const current=controller;attempts++;
  try{
   const response=await fetch(urls[index],{headers:{Range:`bytes=0-${bytes-1}`},cache:'force-cache',credentials:'omit',priority:'low',signal:current.signal});
   const range=response.headers.get('Content-Range');
   if(response.status!==206||!range||Number(response.headers.get('Content-Length')||bytes)>bytes){await response.body?.cancel();index++;}
   else{await response.arrayBuffer();index++;}
  }catch(error){if(error.name!=='AbortError')index++;}
  finally{if(controller===current)controller=null;schedule();}
 }
 const suspend=()=>{controller?.abort();schedule(2500);};
 const onClick=event=>{if(event.target.closest?.('[aria-haspopup="dialog"],.film-tile,.member-work,.profile-film-shelf button'))suspend();};
 const onMedia=event=>{if(event.target.matches?.('.viewer-art video,.profile-film video,#main-video,#member-video'))suspend();};
 const visibility=()=>{if(document.hidden){clearTimeout(timer);controller?.abort();}else schedule();};
 document.addEventListener('click',onClick,true);document.addEventListener('loadstart',onMedia,true);document.addEventListener('visibilitychange',visibility);
 // Covers get first use of the connection. Works beyond the horizontal viewport are still included.
 const covers=works.map(work=>new Promise(resolve=>{const image=new Image();image.decoding='async';image.onload=image.onerror=resolve;image.src=mediaAssetURL(work.poster);}));
 Promise.race([Promise.allSettled(covers),new Promise(resolve=>setTimeout(resolve,12000))]).then(()=>schedule(1000));
 return ()=>{stopped=true;clearTimeout(timer);controller?.abort();document.removeEventListener('click',onClick,true);document.removeEventListener('loadstart',onMedia,true);document.removeEventListener('visibilitychange',visibility);};
}
