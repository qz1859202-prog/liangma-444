import {installMediaCache} from './mediaCache.js';
export function mediaAssetURL(path,base=document.baseURI){const directory=new URL('./',base),url=new URL(path,base);return path.startsWith('/')&&!url.pathname.startsWith(directory.pathname)?new URL('.'+path,directory).href:url.href;}
export function startMediaWarmup(){installMediaCache();return()=>{};}
