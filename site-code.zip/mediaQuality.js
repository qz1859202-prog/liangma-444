export function initialQuality(){return /MicroMessenger/i.test(navigator.userAgent)||navigator.connection?.saveData?'smooth':matchMedia('(pointer:coarse),(max-width:760px)').matches?'mobile':'clear';}
export function playbackURL(work,quality){return work.video.replace('playback.mp4',quality==='smooth'?'smooth.mp4':quality==='mobile'?'mobile.mp4':'playback.mp4');}
