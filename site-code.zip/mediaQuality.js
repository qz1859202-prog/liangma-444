// Use the same HD source on every device.
export function initialQuality(){return 'clear';}
export function playbackURL(work){return work.video;}
