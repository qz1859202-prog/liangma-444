/* Real workflow screenshots, separated into a depth field. No generated nodes. */
const DEFAULT_SCENES = [
  {
    id: 'scene-01', title: '工作流 01', image: './workflow/scene-01.png',
    // Bounds are measured on a 2048 × 1017 rendition of the supplied screenshot.
    extent: [226, 190, 1575, 700],
    nodes: [
      [258,249,40,46],[304,249,43,66],[259,329,42,44],[331,329,42,44],
      [331,376,42,46],[332,432,72,43],[333,480,71,42],[346,534,43,79],
      [328,670,72,47],[329,723,71,40],[559,315,42,57],[558,382,43,76],
      [605,382,44,76],[551,481,42,45],[550,546,74,42],[649,545,76,43],
      [548,591,43,75],[748,255,43,76],[750,343,43,76],[748,429,42,77],
      [803,386,44,59],[848,388,61,48],[861,472,43,74],[866,553,43,76],
      [914,554,43,75],[905,636,42,73],[763,676,72,45],[699,736,43,63],
      [744,737,43,62],[788,738,43,61],[857,739,42,48],[949,736,45,63],
      [902,791,42,56],[951,791,42,57],[1219,272,42,73],[1278,276,43,73],
      [1332,273,43,73],[1512,260,42,77],[1558,260,43,77],[1218,375,42,73],
      [1350,491,42,77],[1218,553,42,72],[1218,647,42,74],[1352,637,43,76],
      [1398,636,43,77],[1724,642,44,75],[1218,748,43,76]
    ]
  },
  {
    id: 'scene-02', title: '工作流 02', image: './workflow/scene-02.png',
    extent: [270, 150, 1745, 765],
    nodes: [
      [307,545,48,29],[395,542,44,33],[395,588,48,29],[397,631,48,30],
      [396,666,48,31],[401,388,49,28],[396,428,48,30],[395,467,49,29],
      [396,507,48,29],[452,390,48,28],[453,431,50,30],[453,474,49,28],
      [458,511,48,29],[508,390,54,29],[511,432,52,28],[511,473,52,29],
      [574,388,51,28],[576,430,49,30],[573,474,51,29],[515,553,38,21],
      [561,550,48,26],[470,309,29,47],[510,309,29,47],[550,309,29,47],
      [636,223,28,49],[637,280,28,50],[637,338,28,50],[732,205,28,49],
      [769,205,29,50],[733,265,28,49],[733,320,29,42],[730,376,48,28],
      [721,429,35,47],[763,429,35,47],[923,425,26,49],[918,188,49,27],
      [924,270,28,48],[1270,271,41,51],[1313,271,41,51],[1355,271,41,51],
      [1399,271,40,51],[1440,272,40,50],[1482,271,28,50],
      [1290,415,29,47],[1336,416,29,47],[1386,416,29,47],[1434,416,29,47],
      [1482,416,29,47],[1297,540,29,48],[1338,539,29,49],[1377,538,29,49],
      [1425,538,29,48],[1489,541,27,47],[1696,540,28,47],
      [1696,269,31,52],[1731,270,31,50],[1892,275,28,49],[1930,275,28,49],
      [1967,275,22,49],[1699,403,26,31],[633,702,30,49],[669,700,30,50],
      [711,701,29,50],[747,703,28,49],[789,701,29,49],[750,781,29,28],
      [749,840,29,50],[841,840,28,50],[905,841,29,49],[1305,740,29,43],
      [1352,699,28,44],[1391,700,28,44],[1425,701,29,44],[1462,701,29,44],
      [1309,791,27,43],[1342,791,28,44],[1374,791,28,44],[1428,791,28,44],
      [1464,791,28,44],[1333,851,28,43],[1367,851,28,43],
      [1703,749,30,43],[1708,813,28,44],[1708,857,28,33]
    ]
  }
];

let instanceCount = 0;
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const button = (action, label, text, extra = '') => `<button type="button" data-wf-action="${action}" aria-label="${label}" ${extra}>${text}</button>`;

/**
 * Mount one interactive workflow stage. Returns { destroy(), reset() }.
 * Images are same-origin and are loaded only when the stage approaches view.
 * No external libraries, fonts, telemetry or network services.
 */
export function mountWorkflowStage(root, options = {}) {
  if (!root) return { destroy() {}, reset() {} };
  const uid = `workflow-stage-${++instanceCount}`;
  const scenes = DEFAULT_SCENES.map((scene, index) => ({ ...scene, image: options.images?.[index] || scene.image }));
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const abort = new AbortController();
  const signal = abort.signal;
  const cache = new Map();
  let activeIndex = 0;
  let loaded = false;
  let loadingToken = 0;
  let disposed = false;
  let isVisible = true;
  let raf = 0;
  let viewportWidth = 1;
  let viewportHeight = 1;
  let rotateMode = true;
  let spatialEnabled = !window.matchMedia('(pointer: coarse)').matches;
  let flat = !spatialEnabled;
  let dragging = false;
  let gestureStart = null;
  let pinchStart = null;
  let previousBodyOverflow = '';
  const points = new Map();
  const target = { rx: -8, ry: -11, x: 0, y: 0, zoom: 1 };
  const current = { ...target };
  let stage = null;
  let activeView = null;

  root.classList.add('wf-root');
  root.dataset.wfTheme = options.theme === 'blue' || options.theme === '444' ? 'blue' : 'dark';
  root.innerHTML = `
    <div class="wf-masthead">
      <div><p class="wf-eyebrow">INSIDE THE PROCESS / 创作的连接方式</p><p class="wf-intro">真实工作流，展开另一层观看。</p></div>
      <span class="wf-depth-label">NODES / CONNECTIONS / DEPTH</span>
    </div>
    <div class="wf-workspace">
      <div class="wf-toolbar">
        <div class="wf-scene-tabs" role="group" aria-label="选择工作流">
          ${scenes.map((scene, i) => `<button type="button" data-wf-scene="${i}" aria-pressed="${i === 0}"><span>0${i + 1}</span>${scene.title}</button>`).join('')}
        </div>
        <div class="wf-controls" role="group" aria-label="工作流展示控制">
          ${button('mode', '切换到原图展示', '立体 <span>3D</span>', 'aria-pressed="true"')}
          ${button('expand', '放大查看工作流', '放大查看 <span>↗</span>')}
        </div>
      </div>
      <div class="wf-viewport" tabindex="0" aria-label="立体工作流，可拖动旋转，使用缩放按钮放大缩小。方向键调整视角，Home复位。" aria-describedby="${uid}-hint">
        <div class="wf-floor" aria-hidden="true"></div>
        <div class="wf-scene-position"><div class="wf-scene" aria-hidden="true"></div></div>
        <div class="wf-loading" role="status">正在展开工作流<span>LOADING THE PROCESS</span></div>
        <div class="wf-corner wf-corner-tl" aria-hidden="true"></div><div class="wf-corner wf-corner-br" aria-hidden="true"></div>
        <span class="wf-coordinate" aria-hidden="true">X / Y / Z</span>
        <span class="wf-view-label">01 / SPATIAL STUDY</span>
      </div>
      <div class="wf-bottom-bar">
        <p id="${uid}-hint" class="wf-hint">拖动旋转 · 双指缩放 <span>Shift 拖动平移</span></p>
        <div class="wf-navigation" role="group" aria-label="调整工作流视角">
          ${button('drag', '切换为平移模式', '旋转 <span>↺</span>', 'aria-pressed="true"')}
          ${button('out', '缩小工作流', '−')}
          <output class="wf-zoom" aria-label="缩放比例">100%</output>
          ${button('in', '放大工作流', '＋')}
          ${button('reset', '复位工作流视角', '复位')}
        </div>
      </div>
    </div>
    <div class="wf-caption"><p>从参考、生成到镜头编排，<br>看见画面之间发生的联系。</p><span>两组真实创作工作流 / ORIGINAL WORKFLOW CAPTURES</span></div>
    <dialog class="wf-dialog" aria-labelledby="${uid}-title">
      <div class="wf-dialog-bar"><div class="wf-window-mark" aria-hidden="true"><i></i><i></i><i></i></div><h3 id="${uid}-title">WORKFLOW / 工作流</h3>${button('close', '关闭工作流大窗', '×')}</div>
      <div class="wf-dialog-content"></div>
    </dialog>`;
  if(flat){root.classList.add('wf-is-flat');const mode=root.querySelector('[data-wf-action=mode]');mode.setAttribute('aria-pressed','false');mode.setAttribute('aria-label','切换到立体展示');mode.innerHTML='原图 <span>2D</span>';}
  const workspace = root.querySelector('.wf-workspace');
  const viewport = root.querySelector('.wf-viewport');
  const sceneEl = root.querySelector('.wf-scene');
  const scenePosition = root.querySelector('.wf-scene-position');
  const status = root.querySelector('.wf-loading');
  const dialog = root.querySelector('.wf-dialog');
  const dialogContent = root.querySelector('.wf-dialog-content');
  const originalParent = workspace.parentElement;
  const originalNext = workspace.nextSibling;
  const modeButton = root.querySelector('[data-wf-action="mode"]');
  const dragButton = root.querySelector('[data-wf-action="drag"]');
  const expandButton = root.querySelector('[data-wf-action="expand"]');

  function fit() {
    const rect = viewport.getBoundingClientRect();
    viewportWidth = rect.width;
    viewportHeight = rect.height;
    if (!stage || !rect.width || !rect.height) return;
    // Keep the complete workflow visible at 100%, including the far plane corners.
    const allowance = flat ? .93 : .85;
    const fitScale = Math.min(rect.width / stage.width, rect.height / stage.height) * allowance;
    scenePosition.style.setProperty('--wf-fit', fitScale.toFixed(5));
    if (!raf) paint();
  }

  function paint() {
    if (!stage) return;
    const rx = flat ? 0 : current.rx;
    const ry = flat ? 0 : current.ry;
    sceneEl.style.transform = `translate3d(${current.x.toFixed(2)}px,${current.y.toFixed(2)}px,0) rotateX(${rx.toFixed(3)}deg) rotateY(${ry.toFixed(3)}deg) scale(${current.zoom.toFixed(4)})`;
    root.querySelector('.wf-zoom').textContent = `${Math.round(current.zoom * 100)}%`;
  }

  function tick() {
    raf = 0;
    if (disposed || (!isVisible && !dialog.open)) return;
    let distance = 0;
    for (const key of Object.keys(current)) {
      const diff = target[key] - current[key];
      if (reduced.matches || Math.abs(diff) < .0008) current[key] = target[key];
      else current[key] += diff * .2;
      distance += Math.abs(target[key] - current[key]);
    }
    paint();
    if (distance > .003) raf = requestAnimationFrame(tick);
  }

  function schedule() {
    if (disposed) return;
    if (!raf && (isVisible || dialog.open)) raf = requestAnimationFrame(tick);
  }

  function reset() {
    Object.assign(target, { rx: -8, ry: -11, x: 0, y: 0, zoom: 1 });
    schedule();
  }

  function setZoom(value) {
    target.zoom = clamp(value, .55, 3.5);
    schedule();
  }

  function setFlat(value) {
    if(!value&&!spatialEnabled){spatialEnabled=true;stashCurrent();cache.clear();selectScene(activeIndex);}
    flat = value;
    root.classList.toggle('wf-is-flat', flat);
    modeButton.setAttribute('aria-pressed', String(!flat));
    modeButton.setAttribute('aria-label', flat ? '切换到立体展示' : '切换到原图展示');
    modeButton.innerHTML = flat ? '原图 <span>2D</span>' : '立体 <span>3D</span>';
    root.querySelector('.wf-view-label').textContent = `${String(activeIndex + 1).padStart(2, '0')} / ${flat ? 'ORIGINAL CAPTURE' : 'SPATIAL STUDY'}`;
    fit();
    schedule();
  }

  function imageReady(src) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.decoding = 'async';
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('Unable to load workflow image'));
      image.src = src;
    });
  }

  async function buildScene(config) {
    if (cache.has(config.id)) return cache.get(config.id);
    const image = await imageReady(config.image);
    const factor = image.naturalWidth / 2048;
    const [ex, ey, ew, eh] = config.extent;
    const fragment = document.createDocumentFragment();
    const original = document.createElement('img');
    original.className = 'wf-original';
    original.src = config.image;
    original.alt = `${config.title}完整原图`;
    original.draggable = false;
    original.style.objectPosition = 'center';
    const imageCrop = document.createElement('div');
    imageCrop.className = 'wf-original-crop';
    imageCrop.style.width = `${ew}px`;
    imageCrop.style.height = `${eh}px`;
    original.style.width = '2048px';
    original.style.height = `${image.naturalHeight / factor}px`;
    original.style.left = `${-ex}px`;
    original.style.top = `${-ey}px`;
    imageCrop.append(original);
    fragment.append(imageCrop);
    if(!spatialEnabled){const built={fragment,width:ew,height:eh,count:0};cache.set(config.id,built);return built;}
    const plane = document.createElement('canvas');
    plane.className = 'wf-connections';
    plane.width = Math.round(ew * factor);
    plane.height = Math.round(eh * factor);
    const context = plane.getContext('2d', { alpha: true });
    context.drawImage(image, ex * factor, ey * factor, ew * factor, eh * factor, 0, 0, plane.width, plane.height);
    // Remove nodes from their original plane: the supplied connecting lines remain.
    context.fillStyle = '#191919';
    fragment.prepend(plane);

    const filtered = config.nodes.filter(([x, y, w, h]) => x >= ex && y >= ey && x + w <= ex + ew && y + h <= ey + eh);
    filtered.forEach(([x, y, w, h], index) => {
      context.fillRect((x - ex - 1) * factor, (y - ey - 1) * factor, (w + 2) * factor, (h + 2) * factor);
      const node = document.createElement('canvas');
      node.className = 'wf-node';
      node.width = Math.round(w * factor);
      node.height = Math.round(h * factor);
      node.getContext('2d', { alpha: false }).drawImage(image, x * factor, y * factor, w * factor, h * factor, 0, 0, node.width, node.height);
      node.style.width = `${w}px`;
      node.style.height = `${h}px`;
      node.style.left = `${x - ex}px`;
      node.style.top = `${y - ey}px`;
      // Deterministic shallow depth preserves the real workflow layout and readability.
      const depth = 24 + (index * 17 % 88);
      node.style.setProperty('--wf-depth', `${depth}px`);
      fragment.append(node);
    });
    // Isolate the existing line geometry from the editor's charcoal background.
    // This retains real connections while allowing both site palettes to show through.
    const pixels = context.getImageData(0, 0, plane.width, plane.height);
    for (let i = 0; i < pixels.data.length; i += 4) {
      const brightness = Math.max(pixels.data[i], pixels.data[i + 1], pixels.data[i + 2]);
      pixels.data[i] = pixels.data[i + 1] = pixels.data[i + 2] = 235;
      pixels.data[i + 3] = brightness < 29 ? 0 : Math.min(150, (brightness - 25) * 4);
    }
    context.putImageData(pixels, 0, 0);
    const built = { fragment, width: ew, height: eh, count: filtered.length };
    cache.set(config.id, built);
    return built;
  }

  async function selectScene(index) {
    if (index < 0 || index >= scenes.length || disposed) return;
    activeIndex = index;
    loaded = true;
    const token = ++loadingToken;
    root.querySelectorAll('[data-wf-scene]').forEach((el, i) => el.setAttribute('aria-pressed', String(index === i)));
    status.hidden = false;
    status.innerHTML = '正在展开工作流<span>LOADING THE PROCESS</span>';
    viewport.setAttribute('aria-busy', 'true');
    try {
      const built = await buildScene(scenes[index]);
      if (token !== loadingToken || disposed) return;
      sceneEl.replaceChildren(built.fragment);
      stage = built;
      // Cache nodes back into a fragment when switching without re-decoding images.
      activeView = index;
      sceneEl.style.width = `${built.width}px`;
      sceneEl.style.height = `${built.height}px`;
      scenePosition.style.width = `${built.width}px`;
      scenePosition.style.height = `${built.height}px`;
      root.querySelector('.wf-view-label').textContent = `${String(index + 1).padStart(2, '0')} / ${flat ? 'ORIGINAL CAPTURE' : 'SPATIAL STUDY'}`;
      status.hidden = true;
      viewport.setAttribute('aria-busy', 'false');
      reset();
      fit();
    } catch (error) {
      if (token !== loadingToken || disposed) return;
      status.innerHTML = '工作流暂未载入<span>请稍后重试，或切换另一组工作流</span>';
      viewport.setAttribute('aria-busy', 'false');
    }
  }

  function stashCurrent() {
    if (activeView === null || !cache.has(scenes[activeView].id)) return;
    const item = cache.get(scenes[activeView].id);
    while (sceneEl.firstChild) item.fragment.append(sceneEl.firstChild);
    activeView = null;
  }

  function changeScene(index) {
    if (index === activeIndex && activeView === index && stage) return;
    stashCurrent();
    selectScene(index);
  }

  function openLarge() {
    if (dialog.open) return;
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialog.showModal();
    dialogContent.append(workspace);
    root.classList.add('wf-expanded');
    dialog.querySelector('[data-wf-action="close"]').focus();
    fit();
    schedule();
  }

  function closeLarge() {
    if (!dialog.open) return;
    originalParent.insertBefore(workspace, originalNext);
    dialog.close();
    document.body.style.overflow = previousBodyOverflow;
    root.classList.remove('wf-expanded');
    fit();
    expandButton.focus({ preventScroll: true });
  }

  root.addEventListener('click', event => {
    const sceneButton = event.target.closest('[data-wf-scene]');
    if (sceneButton) {
      changeScene(Number(sceneButton.dataset.wfScene));
      return;
    }
    const actionButton = event.target.closest('[data-wf-action]');
    if (!actionButton) return;
    switch (actionButton.dataset.wfAction) {
      case 'in': setZoom(target.zoom * 1.22); break;
      case 'out': setZoom(target.zoom / 1.22); break;
      case 'reset': reset(); break;
      case 'mode': setFlat(!flat); break;
      case 'expand': dialog.open ? closeLarge() : openLarge(); break;
      case 'close': closeLarge(); break;
      case 'drag':
        rotateMode = !rotateMode;
        dragButton.setAttribute('aria-pressed', String(rotateMode));
        dragButton.setAttribute('aria-label', rotateMode ? '切换为平移模式' : '切换为旋转模式');
        dragButton.innerHTML = rotateMode ? '旋转 <span>↺</span>' : '平移 <span>↔</span>';
        viewport.classList.toggle('wf-pan-mode', !rotateMode);
        break;
    }
  }, { signal });
  dialog.addEventListener('cancel', event => { event.preventDefault(); closeLarge(); }, { signal });
  dialog.addEventListener('click', event => { if (event.target === dialog) closeLarge(); }, { signal });

  viewport.addEventListener('keydown', event => {
    if (event.key === '+' || event.key === '=') { event.preventDefault(); setZoom(target.zoom * 1.18); }
    else if (event.key === '-') { event.preventDefault(); setZoom(target.zoom / 1.18); }
    else if (event.key === 'Home' || event.key === '0') { event.preventDefault(); reset(); }
    else if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)) {
      event.preventDefault();
      const horizontal = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
      const vertical = event.key === 'ArrowDown' ? 1 : event.key === 'ArrowUp' ? -1 : 0;
      if (event.shiftKey || !rotateMode || flat) { target.x += horizontal * 25; target.y += vertical * 25; }
      else { target.ry = clamp(target.ry + horizontal * 4, -35, 35); target.rx = clamp(target.rx - vertical * 4, -30, 30); }
      schedule();
    }
  }, { signal });

  function distance() {
    const [a, b] = [...points.values()];
    return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0;
  }
  viewport.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !stage) return;
    points.set(event.pointerId, { x: event.clientX, y: event.clientY });
    viewport.setPointerCapture(event.pointerId);
    if (points.size === 2) {
      pinchStart = { distance: distance(), zoom: target.zoom };
      gestureStart = null;
    } else {
      gestureStart = { px: event.clientX, py: event.clientY, x: target.x, y: target.y, rx: target.rx, ry: target.ry, touch: event.pointerType === 'touch' };
    }
    dragging = true;
    viewport.classList.add('wf-dragging');
  }, { signal });
  viewport.addEventListener('pointermove', event => {
    if (!dragging || !points.has(event.pointerId)) return;
    points.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (points.size > 1 && pinchStart) {
      setZoom(pinchStart.zoom * distance() / Math.max(1, pinchStart.distance));
      return;
    }
    if (!gestureStart) return;
    const dx = event.clientX - gestureStart.px;
    const dy = event.clientY - gestureStart.py;
    if (flat || !rotateMode || event.shiftKey) {
      target.x = clamp(gestureStart.x + dx, -viewportWidth * 1.4, viewportWidth * 1.4);
      target.y = clamp(gestureStart.y + dy, -viewportHeight * 1.4, viewportHeight * 1.4);
    } else {
      target.ry = clamp(gestureStart.ry + dx * .09, -35, 35);
      target.rx = clamp(gestureStart.rx - dy * .08, -30, 30);
    }
    schedule();
  }, { signal });
  function endPointer(event) {
    points.delete(event.pointerId);
    if (points.size < 2) pinchStart = null;
    if (!points.size) {
      dragging = false;
      gestureStart = null;
      viewport.classList.remove('wf-dragging');
    } else {
      const [remaining] = [...points.values()];
      gestureStart = { px: remaining.x, py: remaining.y, x: target.x, y: target.y, rx: target.rx, ry: target.ry };
    }
  }
  viewport.addEventListener('pointerup', endPointer, { signal });
  viewport.addEventListener('pointercancel', endPointer, { signal });
  // Normal vertical scrolling remains page scrolling. Ctrl/⌘ + wheel zooms only this stage.
  viewport.addEventListener('wheel', event => {
    if (!event.ctrlKey && !event.metaKey) return;
    event.preventDefault();
    setZoom(target.zoom * Math.exp(-event.deltaY * .008));
  }, { signal, passive: false });

  const resizeObserver = new ResizeObserver(fit);
  resizeObserver.observe(viewport);
  const visibilityObserver = new IntersectionObserver(entries => {
    for (const entry of entries) {
      isVisible = entry.isIntersecting;
      if (isVisible && !loaded) selectScene(0);
      else if (isVisible) schedule();
      else if (raf && !dialog.open) { cancelAnimationFrame(raf); raf = 0; }
    }
  }, { rootMargin: '180px' });
  visibilityObserver.observe(root);
  const onVisibility = () => {
    if (document.hidden && raf) { cancelAnimationFrame(raf); raf = 0; }
    else if (!document.hidden) schedule();
  };
  document.addEventListener('visibilitychange', onVisibility, { signal });

  return {
    reset,
    destroy() {
      if (disposed) return;
      closeLarge();
      disposed = true;
      loadingToken++;
      abort.abort();
      resizeObserver.disconnect();
      visibilityObserver.disconnect();
      if (raf) cancelAnimationFrame(raf);
      cache.clear();
      root.replaceChildren();
      root.classList.remove('wf-root', 'wf-is-flat', 'wf-expanded');
      delete root.dataset.wfTheme;
    }
  };
}
