let registration;
function workerReady(){
 if(!('serviceWorker' in navigator)||!window.isSecureContext)return Promise.reject(Error('此浏览器暂不支持保存'));
 if(!registration){const base=new URL('./',document.baseURI);registration=navigator.serviceWorker.register(new URL('media-cache-sw.js',base),{scope:base.pathname}).then(()=>navigator.serviceWorker.ready);}
 return registration;
}
export function installMediaCache(){workerReady().catch(()=>{});}
export async function filmCacheRequest(path,type='STATUS',onProgress=()=>{}){
 const reg=await workerReady(),worker=reg.active;if(!worker)throw Error('缓存尚未就绪');
 const url=new URL(path,document.baseURI).href;
 return new Promise((resolve,reject)=>{const channel=new MessageChannel();let timer;
 const arm=()=>{clearTimeout(timer);timer=setTimeout(()=>{channel.port1.close();reject(Error('保存超时，请重试'));},190000);};arm();
 channel.port1.onmessage=({data})=>{arm();onProgress(data);if(data.state==='saved'||data.state==='not-saved'||(type==='STATUS'&&data.state==='saving')){clearTimeout(timer);channel.port1.close();resolve(data);}else if(data.state==='error'){clearTimeout(timer);channel.port1.close();reject(Error(data.message));}};
 worker.postMessage({type,url},[channel.port2]);});
}
export function attachFilmCacheButton(button,video,path){
 let alive=true,busy=false;
 const update=data=>{if(!alive)return;if(data.state==='saved'){button.textContent='已保存到本机 ✓';button.disabled=true;}else if(data.state==='saving'){button.textContent=data.total?`正在保存 ${Math.min(99,Math.round(data.received/data.total*100))}%`:'正在保存影片…';}};
 button.textContent='保存影片 ↓';button.disabled=false;
 filmCacheRequest(path).then(update).catch(()=>{});
 const save=async()=>{if(busy)return;busy=true;video.pause();const source=video.getAttribute('src');video.removeAttribute('src');video.load();button.disabled=true;try{await filmCacheRequest(path,'SAVE',update);}catch{if(alive){button.textContent='保存未完成 · 重试';button.disabled=false;}}finally{busy=false;if(alive&&source&&!video.getAttribute('src')){video.src=source;video.load();}}};
 button.addEventListener('click',save);return()=>{alive=false;button.removeEventListener('click',save);};
}
