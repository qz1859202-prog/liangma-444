/* Cache only complete, versioned film files. HTML and application code stay network managed. */
const CACHE='liangma-hd-20261104-'+new URL(self.registration.scope).pathname;
const MAX_FILE=80*1024*1024,MAX_TOTAL=250*1024*1024;
const pending=new Map();
const isFilm=url=>url.origin===self.location.origin&&url.href.startsWith(self.registration.scope)&&/\/films\/[^/]+\/(playback|preview-hd)\.mp4$/.test(url.pathname);
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
async function trim(cache,keep){let total=0;const keys=await cache.keys();for(const key of keys){const hit=await cache.match(key);total+=Number(hit?.headers.get('Content-Length')||0);}for(const key of keys){if(total<=MAX_TOTAL)break;if(key.url===keep)continue;const hit=await cache.match(key);total-=Number(hit?.headers.get('Content-Length')||0);await cache.delete(key);}}
async function ranged(response,range){
 if(!range)return response;
 const match=/^bytes=(\d*)-(\d*)$/.exec(range);
 if(!match||(!match[1]&&!match[2]))return null;
 const blob=await response.blob(),size=blob.size;
 let start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));
 let end=match[1]?(match[2]?Math.min(Number(match[2]),size-1):size-1):size-1;
 if(start>=size||start>end)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});
 const headers=new Headers(response.headers);headers.set('Content-Range',`bytes ${start}-${end}/${size}`);headers.set('Content-Length',String(end-start+1));headers.set('Accept-Ranges','bytes');
 return new Response(blob.slice(start,end+1),{status:206,headers});
}
async function storeComplete(url,response){
 const headers=new Headers(response.headers),range=headers.get('Content-Range');
 const match=range&&/^bytes 0-(\d+)\/(\d+)$/.exec(range);
 const size=Number(headers.get('Content-Length'));
 if(!/video\/mp4|application\/octet-stream/i.test(headers.get('Content-Type')||''))return;
 // A small probe or partial segment must never masquerade as a complete movie.
 if(!(response.status===200||(response.status===206&&match&&Number(match[1])+1===Number(match[2]))))return;
 if(!size||size>MAX_FILE)return;
 headers.delete('Content-Range');headers.set('Accept-Ranges','bytes');
 const cache=await caches.open(CACHE),temporary=url+'?__pending_media=1';let count=0;
 const reader=response.body.getReader();
 const body=new ReadableStream({async pull(controller){try{const part=await reader.read();if(part.done){if(count!==size)throw Error('Incomplete film');controller.close();return;}count+=part.value.byteLength;controller.enqueue(part.value);}catch(error){controller.error(error);}},cancel(reason){return reader.cancel(reason);}});
 try{await cache.put(temporary,new Response(body,{status:200,headers}));const complete=await cache.match(temporary);await cache.put(url,complete);await trim(cache,url);}finally{await cache.delete(temporary);}
}
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);if(request.method!=='GET'||!isFilm(url))return;
 let retention=Promise.resolve();
 const result=(async()=>{
  try{const cache=await caches.open(CACHE),hit=await cache.match(url.href);if(hit){const result=await ranged(hit,request.headers.get('Range'));if(result)return result;}}catch{}
  const response=await fetch(request);
  if(!pending.has(url.href)){
   const task=storeComplete(url.href,response.clone()).catch(()=>{}).finally(()=>pending.delete(url.href));pending.set(url.href,task);retention=task;
  }
  return response;
 })();
 event.respondWith(result);event.waitUntil(result.then(()=>retention).catch(()=>{}));
});
self.addEventListener('message',event=>{
 const {type,url:input}=event.data||{},port=event.ports[0];if(!port)return;
 let url;try{url=new URL(input,self.registration.scope);if(!isFilm(url))throw Error();}catch{port.postMessage({state:'error',message:'Unsupported film'});return;}
 const send=value=>port.postMessage(value);
 event.waitUntil((async()=>{
  const cache=await caches.open(CACHE),hit=await cache.match(url.href);
  if(hit){send({state:'saved',bytes:Number(hit.headers.get('Content-Length'))});return;}
  if(type==='STATUS'){send({state:pending.has(url.href)?'saving':'not-saved'});return;}
  if(type!=='SAVE')return;
  try{
   if(pending.has(url.href)){send({state:'saving'});await pending.get(url.href);if(await cache.match(url.href)){send({state:'saved'});return;}}
   const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),180000);let received=0;
   const task=(async()=>{try{
    const response=await fetch(url.href,{signal:controller.signal,cache:'reload'});if(response.status!==200)throw Error('Download failed');
    const total=Number(response.headers.get('Content-Length'));if(!total||total>MAX_FILE)throw Error('File too large');
    const reader=response.body.getReader();let last=0;
    const body=new ReadableStream({async pull(out){try{const part=await reader.read();if(part.done){out.close();return;}received+=part.value.byteLength;if(Date.now()-last>250){send({state:'saving',received,total});last=Date.now();}out.enqueue(part.value);}catch(error){out.error(error);}},cancel(reason){return reader.cancel(reason);}});
    await storeComplete(url.href,new Response(body,{status:200,headers:response.headers}));
    if(!await cache.match(url.href))throw Error('Film not saved');
   }finally{clearTimeout(timeout);}})();
   pending.set(url.href,task);try{await task;}finally{pending.delete(url.href);}send({state:'saved',bytes:received});
  }catch{send({state:'error',message:'保存未完成，请稍后重试'});}
 })().catch(()=>send({state:'error',message:'当前浏览器无法保存影片，请检查可用空间'})));
});
