// Studio-supplied member biographies.
export const team = [
  {
    "id": "member-1",
    "name": "王超",
    "en": "WANG-CHO0",
    "role": "导演 / AIGC艺术总监",
    "photo": "./team/wang-chao.webp",
    "bio": "浙江大学影像实验室负责人，南京传媒学院AIGC艺术总监；大型公益纪录片《再造多巴胺》导演。",
    "highlights": [
      "中央美术学院 · 艺术硕士",
      "韩国世宗大学 · 艺术博士",
      "浙江大学 · 影像实验室负责人",
      "南京传媒学院 · AIGC艺术总监",
      "大型公益纪录片《再造多巴胺》导演",
      "短片《Nameless》获2023戛纳艺术电影节（AVIFF）评委会特别奖"
    ],
    "pending": false
  },
  {
    "id": "member-2",
    "name": "汤雯荟",
    "en": "TANG WENHUI",
    "role": "执行导演 / AIGC影像创作",
    "photo": "./team/tang-wenhui.webp",
    "bio": "动画专业出身，深耕AIGC影像与传统文化视听创作领域，兼具美术设计与影像执行统筹能力。",
    "highlights": [
      "千间 · 浙江卫视马年春晚《马上好事来》执行导演",
      "千间 · 马年拜年视频执行导演",
      "嘉善重点文化项目《善行天下——袁了凡》执行导演"
    ],
    "pending": false
  },
  {
    "id": "member-3",
    "name": "杨元元",
    "en": "YANG YUANYUAN",
    "role": "AIGC创作者 / 数字媒体艺术",
    "photo": "./team/yang-yuanyuan.webp",
    "bio": "头部大模型创作者，创作覆盖明星演艺经纪、头部卫视与政媒、商业消费及人工智能科技等领域。",
    "highlights": [
      "马来西亚泰莱大学 · 数字媒体艺术",
      "一线艺人戚薇 · AI数字人虚拟影像合作者",
      "新华网、浙江卫视春晚、河南卫视春晚制作者"
    ],
    "pending": false
  },
  {
    "id": "member-4",
    "name": "田超",
    "en": "TIAN CHAO",
    "role": "AIGC工程师 / 影像制作",
    "photo": "./team/tian-chao.webp",
    "bio": "曾参与微电影、纪录片、采访、动画制作与抖音短视频创作，担任副导演、编剧、剪辑与拍摄。\n现从业于AIGC行业，担任AIGC工程师，负责抽卡出图、动效与剪辑。",
    "highlights": [],
    "pending": false
  },
  {
    "id": "member-5",
    "name": "张智博",
    "en": "ZHANG ZHIBO",
    "role": "AIGC影像 / 当代艺术创作",
    "photo": "./team/zhang-zhibo.webp",
    "bio": "动画出身，专注于AIGC影像与当代艺术创作，兼具美术设计、数字角色塑造与影像制作能力，擅长从视觉构思到成片呈现的独立创作。",
    "highlights": [
      "艺人戚薇AI数字人相关虚拟影像合作创作者",
      "新华网、浙江卫视春晚、河南卫视春晚相关影像",
      "海信IP、爱奇艺世界大会及品牌矩阵数字主播相关项目视觉主创、联合主创"
    ],
    "pending": false
  },
  {
    "id": "member-6",
    "name": "",
    "en": "",
    "role": "",
    "photo": "",
    "bio": "",
    "highlights": [],
    "pending": true
  },
  {
    "id": "member-7",
    "name": "",
    "en": "",
    "role": "",
    "photo": "",
    "bio": "",
    "highlights": [],
    "pending": true
  }
];
